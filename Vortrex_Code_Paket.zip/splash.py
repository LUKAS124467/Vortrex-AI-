import customtkinter as ctk
from PIL import Image
import time
import config
import logging

def get_version():
    try:
        with open(config.resource_path("version.txt"), "r", encoding="utf-8") as file:
            return file.read().strip()
    except:
        return "0.0.0"

class SplashScreen(ctk.CTkToplevel):

    def __init__(self, parent):
        super().__init__(parent)

        self.geometry("600x400")
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(fg_color="#0f0f12")

        self.center_window()
        self.lift()

        try:
            img = Image.open(config.SPLASH_PATH)

            self.splash_img = ctk.CTkImage(
                light_image=img,
                dark_image=img,
                size=(350, 200)
            )

            self.image_label = ctk.CTkLabel(
                self,
                image=self.splash_img,
                text=""
            )

            self.image_label.pack(
                pady=(20,10)
            )

        except Exception as e:
            logging.error(f"Splash Bild konnte nicht geladen werden: {e}")


        self.title_label = ctk.CTkLabel(
            self,
            text=config.APP_NAME,
            font=ctk.CTkFont(size=32, weight="bold"),
            text_color="#10b981"
        )

        self.title_label.pack()

        self.version_label = ctk.CTkLabel(
            self,
            text=f"Version {get_version()}",
            font=ctk.CTkFont(size=12),
            text_color="#71717a"
        )

        self.version_label.pack()

        self.status = ctk.CTkLabel(
            self,
            text="Loading Modules...",
            font=ctk.CTkFont(size=16)
        )

        self.status.pack(pady=20)

        self.progress = ctk.CTkProgressBar(
            self,
            width=350
        )

        self.progress.pack(pady=10)

        self.progress.set(0)

        try:
            self.update()
        except:
            pass

    def center_window(self):
        try:
            self.update_idletasks()
        except:
            pass

        width = 600
        height = 400

        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)

        self.geometry(f"{width}x{height}+{x}+{y}")


    def update_status(self, text, progress=None, label=None):
        if label is not None:
            self.status.configure(text=label)
        else:
            self.status.configure(text=text)
        if progress is not None:
            try:
                self.progress.set(progress)
            except Exception:
                pass
        try:
            self.update_idletasks()
        except:
            pass

        if progress is not None:
            time.sleep(0.12 if progress < 1.0 else 0.05)
        else:
            time.sleep(0.05)
