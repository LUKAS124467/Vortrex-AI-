"""Vortrex Tool Manager (Phase 1)

Provides lightweight helpers to locate/manage tool directories and executables.
This Phase 1 implementation intentionally does NOT perform downloads or execute
installers. It only provides path logic, detection helpers and safe directory
creation so the Build Engine can later rely on a stable layout.
"""
import os
import platform
import shutil
from typing import Optional, Dict
import config
import zipfile
import glob
import tempfile
import urllib.request


def get_tool_root() -> str:
    """Return the root tools directory, ensure it exists."""
    root = getattr(config, 'TOOLS_DIR', os.path.join(os.path.dirname(__file__), 'tools'))
    os.makedirs(root, exist_ok=True)
    return root


def get_java_home(version: str = "21") -> str:
    """Return a candidate JAVA_HOME path inside the tools folder for a given version."""
    root = get_tool_root()
    java_home = os.path.join(root, 'java', f'jdk-{version}')
    return java_home


def find_java(version: str = "21") -> Optional[str]:
    """Try to find a java executable for a given version.

    Checks in order:
    - Vortrex internal tools folder
    - JAVA_HOME environment variable
    - system PATH (only returns path, does not modify system)
    """
    # Check internal tools
    java_home = get_java_home(version)
    exe = 'java.exe' if platform.system() == 'Windows' else 'java'
    candidate = os.path.join(java_home, 'bin', exe)
    if os.path.isfile(candidate):
        return candidate

    # Check JAVA_HOME
    env = os.environ.get('JAVA_HOME')
    if env:
        candidate = os.path.join(env, 'bin', exe)
        if os.path.isfile(candidate):
            return candidate

    # Fallback: try to find java on PATH
    from shutil import which
    p = which('java')
    if p:
        return p

    return None


def is_java_installed(version: str = "21") -> bool:
    return find_java(version) is not None


def get_gradle_executable() -> Optional[str]:
    """Return a Gradle executable from Vortrex Tools or the system PATH."""
    root = get_tool_root()
    exe = 'gradle.bat' if platform.system() == 'Windows' else 'gradle'
    candidate = os.path.join(root, 'gradle', 'bin', exe)
    if os.path.isfile(candidate):
        return candidate
    managed = sorted(glob.glob(os.path.join(root, 'gradle', 'gradle-*', 'bin', exe)), reverse=True)
    if managed:
        return managed[0]
    from shutil import which
    return which('gradle')


def ensure_gradle(version: str = '8.10.2') -> Optional[str]:
    """Download and unpack a private Gradle runtime under Vortrex Tools.

    This never changes the global Windows PATH or installs system software.
    It is used only when the user explicitly chooses the Vortrex tool setup.
    """
    existing = get_gradle_executable()
    if existing:
        return existing

    root = os.path.join(get_tool_root(), 'gradle')
    os.makedirs(root, exist_ok=True)
    archive = os.path.join(tempfile.gettempdir(), f'gradle-{version}-bin.zip')
    url = f'https://services.gradle.org/distributions/gradle-{version}-bin.zip'
    try:
        urllib.request.urlretrieve(url, archive)
        with zipfile.ZipFile(archive, 'r') as zf:
            zf.extractall(root)
    except (OSError, urllib.error.URLError, zipfile.BadZipFile):
        return None
    finally:
        try:
            if os.path.isfile(archive):
                os.remove(archive)
        except OSError:
            pass
    return get_gradle_executable()


def get_node_executable() -> Optional[str]:
    root = get_tool_root()
    exe = 'node.exe' if platform.system() == 'Windows' else 'node'
    candidate = os.path.join(root, 'node', 'bin', exe)
    if os.path.isfile(candidate):
        return candidate
    from shutil import which
    return which('node')


def get_maven_home(version: str = "3.9.6") -> str:
    root = get_tool_root()
    return os.path.join(root, 'maven', f'apache-maven-{version}')


def get_maven_executable() -> Optional[str]:
    exe = 'mvn.cmd' if platform.system() == 'Windows' else 'mvn'
    # check internal tools
    # try to find any maven under tools/maven/
    root = get_tool_root()
    candidates = glob.glob(os.path.join(root, 'maven', 'apache-maven-*', 'bin', exe))
    if candidates:
        return candidates[0]
    from shutil import which
    return which('mvn')


def is_maven_installed() -> bool:
    return get_maven_executable() is not None


def get_tool_status() -> Dict[str, bool]:
    """Return a simple status dict for tools we care about."""
    return {
        'java21': is_java_installed('21'),
        'java17': is_java_installed('17'),
        'gradle': get_gradle_executable() is not None,
        'node': get_node_executable() is not None,
        'maven': is_maven_installed(),
    }


def ensure_java(version: str = '21') -> bool:
    """Phase1 placeholder: prepare directory for a JDK but DO NOT download.

    Returns True if the internal target directory exists (created), but does
    not guarantee a working java binary. Downloads and installation belong to
    later phases.
    """
    java_home = get_java_home(version)
    try:
        os.makedirs(java_home, exist_ok=True)
        # write a metadata file to mark the intended version
        meta = os.path.join(java_home, 'VORTREX_TOOL_METADATA.txt')
        with open(meta, 'w', encoding='utf-8') as f:
            f.write(f'jdk-version: {version}\ncreated-by: vortrex tool_manager\n')
        return True
    except Exception:
        return False


if __name__ == '__main__':
    print('Tool root:', get_tool_root())
    print('Java21:', is_java_installed('21'))
    print('Gradle:', get_gradle_executable())
