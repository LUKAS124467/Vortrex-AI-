import json
import logging
import os
import re
import sys
import threading
import time
from datetime import datetime

import customtkinter as ctk
import requests
import tkinter as tk
from tkinter import filedialog
import tkinter.messagebox as messagebox
from PIL import Image

import config
from creation_engine import CreationEngine
import tools.auto_backup as auto_backup


APP_BASE_DIR = config.APP_BASE_DIR


def _kill_stale_vortrex_instances(current_pid=None):
    if getattr(sys, "frozen", False):
        return
    try:
        import subprocess
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
             "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'Vortrex AI.exe' -or ($_.Name -eq 'python.exe' -and $_.CommandLine -match 'vortrex_app.py') } | Select-Object -ExpandProperty ProcessId"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
            creationflags=creation_flags,
        )
        pids = [int(pid) for pid in re.findall(r"\d+", result.stdout or "") if int(pid) != (current_pid or 0)]
        for pid in sorted(set(pids)):
            try:
                os.kill(pid, 9)
            except Exception:
                try:
                    import psutil
                    p = psutil.Process(pid)
                    p.terminate()
                except Exception:
                    pass
    except Exception:
        pass


def _clear_lock_file():
    try:
        lock_path = os.path.join(config.APP_DATA_DIR, "vortrex.lock")
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception:
        pass


def _ensure_single_instance():
    lock_path = os.path.join(config.APP_DATA_DIR, "vortrex.lock")
    os.makedirs(config.APP_DATA_DIR, exist_ok=True)
    try:
        if os.path.exists(lock_path):
            with open(lock_path, "r", encoding="utf-8") as fh:
                existing = fh.read().strip()
            if existing.isdigit():
                try:
                    os.kill(int(existing), 0)
                    return False
                except OSError:
                    pass
            try:
                os.remove(lock_path)
            except OSError:
                pass
        with open(lock_path, "w", encoding="utf-8") as fh:
            fh.write(str(os.getpid()))
        return True
    except Exception:
        return True


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class VortrexDashboard(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{config.APP_NAME} - Smart Dashboard")
        self.geometry("1200x750")
        self.minsize(980, 620)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        try:
            self.iconbitmap(config.ICON_PATH)
        except Exception:
            pass

        self.aktueller_tab = "chat"
        self.ausgewaehlte_datei = ""
        self.user_settings = self._load_user_settings()
        config.OUTPUT_DIR = self.user_settings.get("output_dir", config.DEFAULT_OUTPUT_DIR)
        self.creation_engine = CreationEngine(config.OUTPUT_DIR)
        self.local_chat_history = []

        self.sidebar = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color="#1a1a1a")
        self.sidebar.pack(side="left", fill="y")

        try:
            logo_image = Image.open(config.LOGO_PATH)
            self.logo_img = ctk.CTkImage(light_image=logo_image, dark_image=logo_image, size=(120, 120))
            self.logo_label = ctk.CTkLabel(self.sidebar, image=self.logo_img, text="")
            self.logo_label.pack(padx=20, pady=(25, 5))
        except Exception:
            pass

        self.logo_text = ctk.CTkLabel(self.sidebar, text=config.APP_NAME, font=ctk.CTkFont(size=26, weight="bold"), text_color="#10b981")
        self.logo_text.pack(padx=20, pady=(5, 25))

        self.btn_chat = ctk.CTkButton(self.sidebar, text="💬 Chat / Vortrex AI", font=ctk.CTkFont(size=13), command=lambda: self.wechsle_tab("chat"), fg_color="#2563eb")
        self.btn_chat.pack(padx=15, pady=8, fill="x")

        self.btn_assets = ctk.CTkButton(self.sidebar, text="📦 Minecraft Things", font=ctk.CTkFont(size=13), command=lambda: self.wechsle_tab("assets"), fg_color="#2d2d2d")
        self.btn_assets.pack(padx=15, pady=8, fill="x")

        self.btn_creator = ctk.CTkButton(self.sidebar, text="🛠️ Creator Studio", font=ctk.CTkFont(size=13), command=lambda: self.wechsle_tab("creator"), fg_color="#2d2d2d")
        self.btn_creator.pack(padx=15, pady=8, fill="x")

        self.btn_jarvis = ctk.CTkButton(self.sidebar, text="🤖 Jarvis Mode", font=ctk.CTkFont(size=13), command=lambda: self.wechsle_tab("jarvis"), fg_color="#2d2d2d")
        self.btn_jarvis.pack(side="bottom", padx=15, pady=(8, 18), fill="x")

        self.lbl_verlauf = ctk.CTkLabel(self.sidebar, text="Chat Verlauf", font=ctk.CTkFont(size=12, weight="bold"), text_color="#71717a")
        self.lbl_verlauf.pack(padx=15, pady=(20, 5), anchor="w")

        self.session_list_frame = ctk.CTkScrollableFrame(self.sidebar, fg_color="#141414", corner_radius=5, height=140)
        self.session_list_frame.pack(padx=15, pady=5, fill="x")

        self.hauptbereich = ctk.CTkFrame(self, fg_color="#111318")
        self.hauptbereich.pack(side="left", fill="both", expand=True)

        self.chat_container = ctk.CTkScrollableFrame(self.hauptbereich, fg_color="#111318")
        self.chat_container.pack(padx=20, pady=(20, 10), fill="both", expand=True)

        self.options_frame = ctk.CTkFrame(self.hauptbereich, fg_color="#141922")
        self.btn_opt_a = ctk.CTkButton(self.options_frame, text="Option A", command=lambda: self.sende_option(self.btn_opt_a.cget("text")), fg_color="#2563eb")
        self.btn_opt_b = ctk.CTkButton(self.options_frame, text="Option B", command=lambda: self.sende_option(self.btn_opt_b.cget("text")), fg_color="#2563eb")
        self.btn_opt_c = ctk.CTkButton(self.options_frame, text="Option C", command=lambda: self.sende_option(self.btn_opt_c.cget("text")), fg_color="#2563eb")
        self.btn_opt_a.pack(side="left", padx=(0, 10), expand=True, fill="x")
        self.btn_opt_b.pack(side="left", padx=(0, 10), expand=True, fill="x")
        self.btn_opt_c.pack(side="left", expand=True, fill="x")

        self.bottom_eingabe_frame = ctk.CTkFrame(self.hauptbereich, fg_color="transparent")
        self.bottom_eingabe_frame.pack(padx=20, pady=(0, 18), fill="x")
        self.btn_file_bottom = ctk.CTkButton(self.bottom_eingabe_frame, text="📎", command=self.datei_auswaehlen, fg_color="#374151", width=44, height=40)
        self.btn_file_bottom.pack(side="left", padx=(0, 10))
        self.entry_input_bottom = ctk.CTkEntry(self.bottom_eingabe_frame, placeholder_text="Schreibe eine Nachricht...", font=ctk.CTkFont(size=14), fg_color="#1c1c24", text_color="#ffffff", height=40)
        self.entry_input_bottom.bind("<Return>", self.on_enter_pressed)
        self.entry_input_bottom.pack(side="left", expand=True, fill="x", padx=(0, 10))
        self.btn_senden_bottom = ctk.CTkButton(self.bottom_eingabe_frame, text="Senden", command=self.sende_nachricht, fg_color="#2563eb", width=120, height=40)
        self.btn_senden_bottom.pack(side="right")

        self.jarvis_frame = ctk.CTkFrame(self.hauptbereich, fg_color="#0b0f14", corner_radius=18)
        self.jarvis_frame.pack_forget()

        self.jarvis_access_levels = [
            ("none", "🔒 Kein PC-Zugriff", "Vortrex AI kann nur mit dir sprechen."),
            ("basic", "📂 Basiszugriff", "Vortrex AI darf Apps, Programme, Ordner und Webseiten öffnen."),
            ("extended", "🛠️ Erweiterter Zugriff", "Vortrex AI darf Dateien bearbeiten und Projekte verwalten."),
            ("confirm", "⚠️ Bestätigung erforderlich", "Vortrex AI fragt vor wichtigen PC-Aktionen nach."),
            ("full", "🖥️ Ganzer PC-Zugriff", "Vortrex AI darf alle vorgesehenen PC-Funktionen nutzen."),
        ]
        self.jarvis_access_level = "none"
        self.jarvis_access_label_map = {key: label for key, label, _ in self.jarvis_access_levels}
        self.jarvis_access_help_map = {key: help_text for key, _, help_text in self.jarvis_access_levels}

        self.jarvis_header = ctk.CTkFrame(self.jarvis_frame, fg_color="transparent")
        self.jarvis_header.pack(fill="x", padx=22, pady=(18, 8))
        self.jarvis_title = ctk.CTkLabel(self.jarvis_header, text="Vortrex AI", font=ctk.CTkFont(size=26, weight="bold"), text_color="#e5e7eb")
        self.jarvis_title.pack(side="left")
        self.jarvis_access_button = ctk.CTkButton(self.jarvis_header, text=self.jarvis_access_label_map[self.jarvis_access_level] + " ▼", command=self._show_jarvis_access_menu, fg_color="#1f2937", hover_color="#374151", height=36)
        self.jarvis_access_button.pack(side="right")

        self.jarvis_visual_wrap = ctk.CTkFrame(self.jarvis_frame, fg_color="#0f1621", corner_radius=24)
        self.jarvis_visual_wrap.pack(fill="both", expand=True, padx=22, pady=(8, 14))
        self.jarvis_status_label = ctk.CTkLabel(self.jarvis_visual_wrap, text="Wie kann ich helfen?", font=ctk.CTkFont(size=18, weight="bold"), text_color="#d1d5db")
        self.jarvis_status_label.pack(pady=(10, 8))
        self.jarvis_hint_label = ctk.CTkLabel(self.jarvis_visual_wrap, text="Die Kugel reagiert auf Sprache, Pausen und den aktuellen Vortrex-AI-Zustand.", font=ctk.CTkFont(size=12), text_color="#94a3b8")
        self.jarvis_hint_label.pack(pady=(0, 14))

        self.jarvis_input_frame = ctk.CTkFrame(self.jarvis_frame, fg_color="#111827", corner_radius=18)
        self.jarvis_input_frame.pack(fill="x", padx=22, pady=(0, 22))
        self.entry_input_jarvis = ctk.CTkEntry(self.jarvis_input_frame, placeholder_text="Schreibe an Vortrex AI...", font=ctk.CTkFont(size=14), fg_color="#1c1c24", text_color="#ffffff", height=42)
        self.entry_input_jarvis.bind("<Return>", self.on_enter_pressed)
        self.entry_input_jarvis.pack(side="left", expand=True, fill="x", padx=(16, 12), pady=16)
        self.btn_senden_jarvis = ctk.CTkButton(self.jarvis_input_frame, text="Senden", font=ctk.CTkFont(weight="bold"), command=self.sende_nachricht, fg_color="#2563eb", width=120, height=42)
        self.btn_senden_jarvis.pack(side="right", padx=(0, 16), pady=16)

        self._jarvis_access_menu = tk.Menu(self, tearoff=0)
        self._jarvis_access_menu.configure(bg="#111827", fg="#f9fafb", activebackground="#2563eb", activeforeground="#ffffff")
        for key, label, help_text in self.jarvis_access_levels:
            self._jarvis_access_menu.add_command(label=f"{label} - {help_text}", command=lambda access_key=key: self._set_jarvis_access_level(access_key))

        self.local_chat_history = self._load_local_chat_history()
        self._clear_server_history()
        self.refresh_session_list()
        self.fuege_chat_blase_hinzu("jarvis", "System aktiv. Bereit für Eingaben.")
        self._apply_startup_screen()

    def _default_user_settings(self):
        return {"first_run_complete": True, "output_dir": config.DEFAULT_OUTPUT_DIR, "startup_screen": "primary"}

    def _load_user_settings(self):
        defaults = self._default_user_settings()
        try:
            os.makedirs(config.APP_DATA_DIR, exist_ok=True)
            if os.path.isfile(config.SETTINGS_FILE):
                with open(config.SETTINGS_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                if isinstance(saved, dict):
                    defaults.update({k: v for k, v in saved.items() if k in defaults})
        except Exception:
            pass
        defaults["output_dir"] = str(defaults.get("output_dir") or config.DEFAULT_OUTPUT_DIR).strip() or config.DEFAULT_OUTPUT_DIR
        defaults["startup_screen"] = str(defaults.get("startup_screen") or "primary")
        return defaults

    def _save_user_settings(self):
        try:
            os.makedirs(config.APP_DATA_DIR, exist_ok=True)
            with open(config.SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.user_settings, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def _apply_startup_screen(self):
        try:
            self.update_idletasks()
            width = self.winfo_width() or 1200
            height = self.winfo_height() or 750
            mode = self.user_settings.get("startup_screen", "primary")
            if mode == "centered":
                x = (self.winfo_screenwidth() // 2) - (width // 2)
                y = (self.winfo_screenheight() // 2) - (height // 2)
                self.geometry(f"{width}x{height}+{x}+{y}")
            elif mode == "remember":
                x, y = 100, 80
                self.geometry(f"{width}x{height}+{x}+{y}")
            else:
                self.geometry(f"{width}x{height}")
        except Exception:
            pass

    def _show_jarvis_access_menu(self):
        try:
            x = self.jarvis_access_button.winfo_rootx()
            y = self.jarvis_access_button.winfo_rooty() + self.jarvis_access_button.winfo_height()
            self._jarvis_access_menu.tk_popup(x, y)
        finally:
            try:
                self._jarvis_access_menu.grab_release()
            except Exception:
                pass

    def _set_jarvis_access_level(self, access_key):
        if access_key not in self.jarvis_access_label_map:
            return
        self.jarvis_access_level = access_key
        self.jarvis_access_button.configure(text=self.jarvis_access_label_map[access_key] + " ▼")
        self.jarvis_hint_label.configure(text=self.jarvis_access_help_map[access_key])

    def fuege_chat_blase_hinzu(self, sender, text):
        if not hasattr(self, "chat_container"):
            return

        def _insert():
            if sender == "user":
                bubble_color = "#2563eb"
                name = "👤 Du"
                anchor = "e"
                label_anchor = "e"
            else:
                bubble_color = "#10b981"
                name = "🤖 Vortrex AI"
                anchor = "w"
                label_anchor = "w"

            bubble = ctk.CTkFrame(self.chat_container, fg_color=bubble_color, corner_radius=15)
            label_name = ctk.CTkLabel(bubble, text=name, font=ctk.CTkFont(size=12, weight="bold"), text_color="white")
            label_name.pack(anchor=label_anchor, fill="x", padx=15, pady=(8, 0))
            label_text = ctk.CTkLabel(bubble, text=text, font=ctk.CTkFont(size=14), text_color="white", wraplength=600, justify="right" if sender == "user" else "left")
            label_text.pack(anchor=label_anchor, fill="x", padx=15, pady=(5, 10))
            bubble.pack(anchor=anchor, padx=20, pady=8, fill="x")
            try:
                self.chat_container._parent_canvas.yview_moveto(1.0)
            except Exception:
                pass

        self.after(0, _insert)

    def _on_close(self):
        try:
            _clear_lock_file()
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass

    def _load_local_chat_history(self):
        try:
            d = config.CHATS_DIR
            if os.path.isdir(d):
                files = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".json")]
                if files:
                    files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
                    for latest in files:
                        try:
                            with open(latest, "r", encoding="utf-8") as f:
                                data = json.load(f)
                            if isinstance(data, list):
                                return data
                        except Exception:
                            pass
        except Exception:
            pass
        chat_file = os.path.join(config.LOGS_DIR, "chat_history.json")
        if os.path.exists(chat_file):
            try:
                with open(chat_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return data
            except Exception:
                pass
        return []

    def _save_local_chat_history(self):
        os.makedirs(config.LOGS_DIR, exist_ok=True)
        chat_file = os.path.join(config.LOGS_DIR, "chat_history.json")
        try:
            with open(chat_file, "w", encoding="utf-8") as f:
                json.dump(self.local_chat_history, f, ensure_ascii=False, indent=4)
        except Exception:
            pass

    def _append_local_chat_history(self, sender, text):
        self.local_chat_history.append({"sender": sender, "text": text})
        self._save_local_chat_history()

    def _get_session_dir(self):
        os.makedirs(config.CHATS_DIR, exist_ok=True)
        return config.CHATS_DIR

    def _save_current_session(self):
        if not self.local_chat_history:
            return
        name = datetime.now().strftime("session_%Y%m%d_%H%M%S.json")
        path = os.path.join(self._get_session_dir(), name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.local_chat_history, f, ensure_ascii=False, indent=2)

    def _clear_server_history(self):
        try:
            requests.post(f"{config.SERVER_URL}/api/clear", json={"tab": "all"}, timeout=5)
        except Exception:
            pass

    def refresh_session_list(self):
        for child in self.session_list_frame.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass
        sessions = []
        d = self._get_session_dir()
        for file in sorted(os.listdir(d), key=lambda f: os.path.getmtime(os.path.join(d, f)), reverse=True):
            if file.endswith(".json"):
                sessions.append((file, os.path.join(d, file)))
        if not sessions:
            ctk.CTkLabel(self.session_list_frame, text="Keine alten Chats.", text_color="#a1a1aa").pack(anchor="w", padx=8, pady=4)
            return
        for name, path in sessions[:10]:
            btn = ctk.CTkButton(self.session_list_frame, text=f"{name}", anchor="w", fg_color="#2d2d2d", command=lambda p=path: self._load_session_file(p))
            btn.pack(fill="x", pady=4, padx=6)

    def _load_session_file(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                self.local_chat_history = data
                self._save_local_chat_history()
                self._render_local_history()
        except Exception:
            pass

    def _render_local_history(self):
        for child in self.chat_container.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass
        for msg in self.local_chat_history:
            sender = msg.get("sender", "jarvis")
            text = msg.get("text", "")
            if text:
                self.fuege_chat_blase_hinzu(sender, text)

    def wechsle_tab(self, ziel_tab):
        self.aktueller_tab = ziel_tab
        for btn_name in ["btn_chat", "btn_creator", "btn_jarvis", "btn_assets"]:
            btn = getattr(self, btn_name, None)
            if btn is not None:
                btn.configure(fg_color="#2d2d2d")

        self.chat_container.pack_forget()
        self.bottom_eingabe_frame.pack_forget()
        self.options_frame.pack_forget()
        self.jarvis_frame.pack_forget()

        if ziel_tab == "chat":
            self.btn_chat.configure(fg_color="#2563eb")
            self.chat_container.pack(padx=20, pady=(20, 10), expand=True, fill="both")
            self.bottom_eingabe_frame.pack(padx=20, pady=(0, 18), fill="x")
            self._render_local_history()
        elif ziel_tab == "jarvis":
            self.btn_jarvis.configure(fg_color="#2563eb")
            self.jarvis_frame.pack(fill="both", expand=True, padx=20, pady=20)
        elif ziel_tab == "assets":
            self.btn_assets.configure(fg_color="#2563eb")
            self.chat_container.pack(padx=20, pady=(20, 10), expand=True, fill="both")
            self.bottom_eingabe_frame.pack(padx=20, pady=(0, 18), fill="x")
            self._render_local_history()
        elif ziel_tab == "creator":
            self.btn_creator.configure(fg_color="#2563eb")
            self.chat_container.pack(padx=20, pady=(20, 10), expand=True, fill="both")
            self.bottom_eingabe_frame.pack(padx=20, pady=(0, 18), fill="x")
            self._render_local_history()

    def datei_auswaehlen(self):
        dateipfad = filedialog.askopenfilename(title="Wähle eine Minecraft-Datei", filetypes=[("Minecraft-Dateien", "*.jar *.zip"), ("Alle Dateien", "*.*")])
        if dateipfad:
            self.ausgewaehlte_datei = dateipfad
            entry = self.entry_input_bottom if self.aktueller_tab in ["chat", "creator", "assets"] else self.entry_input_jarvis
            entry.delete(0, "end")
            entry.insert(0, f"Datei: {os.path.basename(dateipfad)} -> ")

    def _build_cheat_lab(self):
        header = ctk.CTkFrame(self.cheat_lab_frame, fg_color="transparent")
        header.pack(fill="x", padx=22, pady=(18, 8))
        ctk.CTkLabel(
            header,
            text="🧪 Cheat Lab",
            font=ctk.CTkFont(size=26, weight="bold"),
            text_color="#e5e7eb",
        ).pack(anchor="w")
        ctk.CTkLabel(
            header,
            text="Debug-Cheats für dein eigenes Spiel oder eine lokale Sandbox",
            text_color="#94a3b8",
        ).pack(anchor="w", pady=(3, 0))

        notice = ctk.CTkLabel(
            self.cheat_lab_frame,
            text="Sicherheitsgrenze: keine Fremdspiel-Manipulation, Speicherzugriffe oder Anti-Cheat-Umgehung.",
            text_color="#fbbf24",
            anchor="w",
            justify="left",
        )
        notice.pack(fill="x", padx=22, pady=(4, 12))

        prompt_card = ctk.CTkFrame(self.cheat_lab_frame, fg_color="#111827", corner_radius=14)
        prompt_card.pack(fill="x", padx=22, pady=(0, 12))
        ctk.CTkLabel(
            prompt_card,
            text="Was soll der Debug-Cheat in deinem eigenen Spiel tun?",
            text_color="#d1d5db",
        ).pack(anchor="w", padx=14, pady=(12, 5))
        self.cheat_prompt_entry = ctk.CTkEntry(
            prompt_card,
            placeholder_text="z. B. Fly-Modus als lokalen Debug-Schalter erstellen",
            height=40,
        )
        self.cheat_prompt_entry.pack(side="left", fill="x", expand=True, padx=(14, 8), pady=(0, 14))
        self.cheat_prompt_entry.bind("<Return>", lambda _event: self._generate_debug_cheat())
        self.cheat_language = ctk.CTkOptionMenu(
            prompt_card,
            values=["Minecraft Paper (Java)", "Python", "C#"],
            width=110,
        )
        self.cheat_language.pack(side="left", padx=(0, 8), pady=(0, 14))
        ctk.CTkButton(
            prompt_card,
            text="Code erzeugen",
            command=self._generate_debug_cheat,
            fg_color="#10b981",
            hover_color="#059669",
            width=130,
        ).pack(side="right", padx=(0, 14), pady=(0, 14))

        preset_card = ctk.CTkFrame(self.cheat_lab_frame, fg_color="#111827", corner_radius=14)
        preset_card.pack(fill="x", padx=22, pady=(0, 12))
        ctk.CTkLabel(preset_card, text="Minecraft-Vorlagen:", text_color="#d1d5db").pack(
            side="left", padx=(14, 8), pady=12
        )
        self.minecraft_preset = ctk.CTkOptionMenu(
            preset_card,
            values=[
                "Fly/Doppelsprung",
                "Speed",
                "Unverwundbarkeit",
                "Nachtsicht",
                "Teleport",
                "Item geben",
                "Zeit und Wetter",
                "Gamemode",
            ],
            width=180,
        )
        self.minecraft_preset.pack(side="left", padx=8, pady=12)
        ctk.CTkButton(
            preset_card,
            text="Vorlage einsetzen",
            command=self._insert_minecraft_preset,
            width=130,
            fg_color="#374151",
        ).pack(side="left", padx=8, pady=12)

        output_card = ctk.CTkFrame(self.cheat_lab_frame, fg_color="#111827", corner_radius=14)
        output_card.pack(fill="both", expand=True, padx=22, pady=(0, 12))
        output_header = ctk.CTkFrame(output_card, fg_color="transparent")
        output_header.pack(fill="x", padx=14, pady=(10, 4))
        ctk.CTkLabel(
            output_header,
            text="Generierter Sandbox-Code",
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left")
        ctk.CTkButton(
            output_header,
            text="Kopieren",
            command=self._copy_debug_cheat,
            width=90,
            fg_color="#374151",
        ).pack(side="right", padx=(8, 0))
        ctk.CTkButton(
            output_header,
            text="Speichern",
            command=self._save_debug_cheat,
            width=90,
            fg_color="#374151",
        ).pack(side="right")
        self.cheat_output = ctk.CTkTextbox(
            output_card,
            font=("Consolas", 12),
            fg_color="#0b0f14",
            text_color="#d1d5db",
            wrap="none",
        )
        self.cheat_output.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self.cheat_output.insert("1.0", "# Beschreibe oben einen Debug-Cheat für dein eigenes Spiel.\n")

    def _debug_cheat_code(self, prompt, language):
        prompt_low = prompt.lower()
        if language == "Minecraft Paper (Java)":
            return self._minecraft_debug_code(prompt)
        if any(word in prompt_low for word in ("fly", "fliegen", "flug")):
            if language == "C#":
                return """// Lokaler Debug-Schalter für dein eigenes Spiel.
// Nur an deine eigene Player-/Movement-Komponente anbinden.
public sealed class DebugFlightToggle
{
    public bool Enabled { get; private set; }

    public void ToggleFlight()
    {
        Enabled = !Enabled;
    }

    public void ApplyTo(YourPlayerController player)
    {
        player.AllowFreeFlight = Enabled;
    }
}
"""
            return """class DebugFlightToggle:
    """ + '"""Lokaler Debug-Schalter für dein eigenes Spiel."""' + """
    def __init__(self):
        self.enabled = False

    def toggle(self):
        self.enabled = not self.enabled

    def apply_to(self, player):
        # player ist deine eigene Player-/Movement-Komponente.
        player.allow_free_flight = self.enabled
"""

        if language == "C#":
            return f"""// Lokaler Debug-Befehl für dein eigenes Spiel: {prompt}
// Verbinde ihn mit deiner eigenen Debug-Konsole oder Testszene.
public static class LocalDebugCommand
{{
    public static void Execute(YourGameState state)
    {{
        // TODO: Eigene Spielvariable kontrolliert setzen.
        state.SetDebugFlag("{prompt.replace('"', '')}", true);
    }}
}}
"""
        return f"""# Lokaler Debug-Befehl für dein eigenes Spiel: {prompt}
# Nur mit deiner eigenen Spielzustands-Klasse verbinden.
def execute_debug_command(game_state):
    game_state.set_debug_flag({prompt!r}, True)
"""

    def _insert_minecraft_preset(self):
        preset = self.minecraft_preset.get()
        prompts = {
            "Fly/Doppelsprung": "Fly-Debug-Modus für OPs umschalten",
            "Speed": "Speed-Debug-Modus mit kontrolliertem Multiplikator",
            "Unverwundbarkeit": "temporäre Unverwundbarkeit für die Testwelt",
            "Nachtsicht": "Nachtsicht für die Testwelt umschalten",
            "Teleport": "Spieler zu sicheren Testkoordinaten teleportieren",
            "Item geben": "Testitem an einen Spieler geben",
            "Zeit und Wetter": "Zeit auf Tag setzen und Wetter stoppen",
            "Gamemode": "Gamemode für OPs auf Creative setzen",
        }
        self.cheat_prompt_entry.delete(0, "end")
        self.cheat_prompt_entry.insert(0, prompts[preset])
        self.cheat_language.set("Minecraft Paper (Java)")

    def _minecraft_debug_code(self, prompt):
        prompt_low = prompt.lower()
        if any(word in prompt_low for word in ("fly", "fliegen", "flug", "doppelsprung")):
            body = """        player.setAllowFlight(!player.getAllowFlight());
        player.sendMessage("Fly-Debug: " + (player.getAllowFlight() ? "AN" : "AUS"));
"""
            command = "flydebug"
        elif "speed" in prompt_low:
            body = """        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.2f);
        player.sendMessage("Speed-Debug aktiviert.");
"""
            command = "speeddebug"
        elif any(word in prompt_low for word in ("unverwund", "god", "unsterb")):
            body = """        player.setInvulnerable(!player.isInvulnerable());
        player.sendMessage("Unverwundbarkeit: " + (player.isInvulnerable() ? "AN" : "AUS"));
"""
            command = "goddebug"
        elif "nachtsicht" in prompt_low:
            body = """        player.addPotionEffect(new PotionEffect(
            PotionEffectType.NIGHT_VISION, 20 * 60 * 10, 0, false, false));
        player.sendMessage("Nachtsicht für 10 Minuten gesetzt.");
"""
            command = "nightvision"
        elif "teleport" in prompt_low:
            body = """        player.teleport(player.getWorld().getSpawnLocation());
        player.sendMessage("Zum Spawn teleportiert.");
"""
            command = "testtp"
        elif any(word in prompt_low for word in ("item", "geben", "give")):
            body = """        player.getInventory().addItem(new ItemStack(Material.DIAMOND, 1));
        player.sendMessage("Testitem gegeben.");
"""
            command = "testitem"
        elif any(word in prompt_low for word in ("zeit", "wetter", "tag")):
            body = """        player.getWorld().setTime(1000);
        player.getWorld().setStorm(false);
        player.getWorld().setThundering(false);
        player.sendMessage("Testwelt: Tag und klares Wetter.");
"""
            command = "testworld"
        elif any(word in prompt_low for word in ("gamemode", "creative", "spielmodus")):
            body = """        player.setGameMode(GameMode.CREATIVE);
        player.sendMessage("Creative-Testmodus gesetzt.");
"""
            command = "creativedebug"
        else:
            body = """        player.sendMessage("Unbekannter Debug-Befehl. Nutze eine Vorlage im Cheat Lab.");
"""
            command = "debuginfo"

        return f"""// Sichere Paper-Debug-Vorlage für deinen eigenen Minecraft-Server.
// Nur für lokale Testwelten / Server verwenden und Berechtigungen beibehalten.
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class DebugCheatCommand implements CommandExecutor {{
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {{
        if (!(sender instanceof Player player)) {{
            sender.sendMessage("Nur Spieler können diesen Testbefehl verwenden.");
            return true;
        }}
        if (!player.hasPermission("vortrex.debug")) {{
            player.sendMessage("Keine Berechtigung: vortrex.debug");
            return true;
        }}
{body}        return true;
    }}
}}

// plugin.yml:
// commands:
//   {command}:
//     description: Lokaler Vortrex-Debug-Befehl
//     permission: vortrex.debug
"""

    def _generate_debug_cheat(self):
        prompt = self.cheat_prompt_entry.get().strip()
        if not prompt:
            messagebox.showinfo("Eingabe fehlt", "Beschreibe zuerst den Debug-Cheat.")
            return
        language = self.cheat_language.get()
        self.cheat_output.delete("1.0", "end")
        self.cheat_output.insert("1.0", self._debug_cheat_code(prompt, language))

    def _copy_debug_cheat(self):
        code = self.cheat_output.get("1.0", "end-1c").strip()
        if not code:
            return
        self.clipboard_clear()
        self.clipboard_append(code)
        self.update()

    def _save_debug_cheat(self):
        code = self.cheat_output.get("1.0", "end-1c").strip()
        if not code:
            return
        language = self.cheat_language.get()
        extension = ".java" if language == "Minecraft Paper (Java)" else ".cs" if language == "C#" else ".py"
        path = filedialog.asksaveasfilename(
            title="Debug-Code speichern",
            defaultextension=extension,
            filetypes=[
                ("Java-Datei", "*.java"),
                ("C#-Datei", "*.cs"),
                ("Python-Datei", "*.py"),
                ("Alle Dateien", "*.*"),
            ],
        )
        if path:
            with open(path, "w", encoding="utf-8") as file:
                file.write(code + "\n")

    def _is_minecraft_prompt(self, text):
        prompt_low = (text or "").lower()
        if not prompt_low:
            return False
        if "minecraft" in prompt_low or "minecrft" in prompt_low:
            return True

        patterns = [
            r"\bmods?\b",
            r"\bplugin(s)?\b",
            r"\bpaper\b",
            r"\bpurpur\b",
            r"\bspigot\b",
            r"\bbukkit\b",
            r"\bfabric\b",
            r"\bforge\b",
            r"\bneoforge\b",
            r"\bresource pack\b",
            r"\bressourcenpaket\b",
            r"\btexture pack\b",
            r"\btexturpack\b",
            r"\bshader(s|pack)?\b",
            r"\biris\b",
            r"\boptifine\b",
            r"\bdatapack\b",
        ]
        return any(re.search(pattern, prompt_low) for pattern in patterns)

    def _current_entry(self):
        if self.aktueller_tab == "jarvis":
            return self.entry_input_jarvis
        return self.entry_input_bottom

    def on_enter_pressed(self, event):
        self.sende_nachricht()
        return "break"

    def sende_option(self, option_text):
        entry = self._current_entry()
        entry.delete(0, "end")
        entry.insert(0, option_text)
        self.sende_nachricht()

    def sende_nachricht(self):
        entry = self._current_entry()
        user_text = entry.get().strip()
        if not user_text and not self.ausgewaehlte_datei:
            return

        if self.aktueller_tab in ["chat", "jarvis", "ideas"] and self._is_minecraft_prompt(user_text):
            self.wechsle_tab("assets")
            entry = self._current_entry()
            user_text = entry.get().strip()

        text_fuer_chat = f"[📎 {os.path.basename(self.ausgewaehlte_datei)}] {user_text}" if self.ausgewaehlte_datei else user_text
        self.fuege_chat_blase_hinzu("user", text_fuer_chat)
        self._append_local_chat_history("user", text_fuer_chat)
        entry.delete(0, "end")
        self.ausgewaehlte_datei = ""

        def _local_fallback_answer(prompt):
            prompt = (prompt or "").strip()
            if not prompt:
                return "Keine Eingabe"
            return "KI-Dienst nicht verfügbar. API-Verbindung prüfen."

        def _is_stale_action_reply(text):
            value = (text or "").strip().lower()
            if not value:
                return False
            markers = [
                "aktion erfolgreich ausgeführt",
                "aktion wurde erfolgreich",
                "die aktion wurde erfolgreich",
                "erfolgreich ausgeführt",
                "✅ aktion",
            ]
            return any(marker in value for marker in markers)

        def _compact_ui_text(text):
            value = (text or "").strip()
            if not value:
                return "Keine Eingabe"
            value = re.sub(r"\s+", " ", value)
            value = value.replace('"', '')
            value = value.replace("Sir, ", "")
            value = value.replace("Ich habe deine Anfrage verstanden: ", "")
            value = value.replace("ich habe deine Anfrage verstanden: ", "")
            value = value.replace("Ich habe dein Minecraft-Projekt erkannt: ", "Minecraft: ")
            value = value.replace("Wenn du willst, kann ich daraus sofort ein passendes Projekt-Layout erzeugen.", "")
            value = value.replace("Dein Auftrag: ", "Auftrag: ")
            value = value.strip()
            if len(value) <= 240:
                return value
            sentence_matches = list(re.finditer(r"[.!?](?:\s|$)", value[:240]))
            if sentence_matches:
                return value[: sentence_matches[-1].start() + 1].strip()
            return value

        def hintergrund_anfrage():
            answer = _local_fallback_answer(user_text)
            try:
                if self.aktueller_tab == "assets" and self._is_minecraft_prompt(user_text):
                    payload = {"prompt": user_text}
                    response = requests.post(f"{config.SERVER_URL}/api/create", json=payload, timeout=20)
                    if response.ok:
                        data = response.json()
                        if data.get("artifact") or data.get("project_dir"):
                            answer = data.get("message") or data.get("result") or f"Minecraft-Projekt wurde erstellt: {data.get('project_dir', 'Ausgabeordner')}"
                        else:
                            answer = data.get("result") or data.get("message") or answer
                        if _is_stale_action_reply(answer):
                            answer = _local_fallback_answer(user_text)
                        answer = _compact_ui_text(answer)
                    else:
                        answer = "Minecraft-Erstellung wurde vorbereitet. Der Builder wurde gestartet."
                else:
                    response = requests.post(f"{config.SERVER_URL}/api/chat", json={"message": user_text}, timeout=20)
                    if response.ok:
                        data = response.json()
                        payload_answer = data.get("answer") or data.get("result") or data.get("message")
                        if payload_answer:
                            if (
                                _is_stale_action_reply(str(payload_answer))
                                or "ich habe deine anfrage verstanden" in str(payload_answer).lower()
                            ):
                                answer = _local_fallback_answer(user_text)
                            else:
                                answer = str(payload_answer)
                                answer = _compact_ui_text(answer)
            except Exception:
                answer = _local_fallback_answer(user_text)

            self.after(0, lambda: self.fuege_chat_blase_hinzu("jarvis", answer))
            self.after(0, lambda: self._append_local_chat_history("jarvis", answer))

        threading.Thread(target=hintergrund_anfrage, daemon=True).start()

    def neuen_chat_starten(self):
        try:
            self._save_current_session()
        except Exception:
            pass
        self.local_chat_history = []
        self._save_local_chat_history()
        for child in self.chat_container.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass
        self.fuege_chat_blase_hinzu("jarvis", "System aktiv. Bereit für Eingaben.")


if __name__ == "__main__":
    try:
        _kill_stale_vortrex_instances(os.getpid())
        if not _ensure_single_instance():
            print("Vortrex AI läuft bereits. Doppelte Instanz wird beendet.")
            sys.exit(0)

        app = VortrexDashboard()
        app.mainloop()
    except Exception as exc:
        logging.exception("Fehler beim Start der Anwendung: %s", exc)
        raise
