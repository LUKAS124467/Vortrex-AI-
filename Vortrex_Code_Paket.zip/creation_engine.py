import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any


class CreationError(ValueError):
    """Raised when a creation request cannot be handled safely."""


class CreationEngine:
    """Plans and scaffolds projects inside one controlled output directory."""

    def __init__(self, output_dir: str | Path):
        self.output_dir = Path(output_dir).resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def create(self, prompt: str) -> dict[str, Any]:
        prompt = prompt.strip()
        if not prompt:
            raise CreationError("Der Erstellungsauftrag darf nicht leer sein.")

        plan = self.plan(prompt)
        project_dir = self._project_path(plan["name"])
        project_dir.mkdir(parents=True, exist_ok=True)

        files = self._files_for_plan(plan)
        written_files = []
        for relative_path, content in files.items():
            target = self._safe_child(project_dir, relative_path)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            written_files.append(str(target.relative_to(project_dir)))

        manifest = dict(plan)
        manifest["status"] = "scaffolded"
        manifest["project_dir"] = str(project_dir)
        manifest["files"] = sorted(written_files)
        (project_dir / "vortrex.project.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8"
        )
        manifest["files"].append("vortrex.project.json")
        if plan["type"] == "minecraft_plugin":
            self._build_minecraft_plugin(project_dir, manifest)
            (project_dir / "vortrex.project.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8"
            )
        elif plan["type"] in ("minecraft_resource_pack", "minecraft_shader_pack"):
            archive = shutil.make_archive(str(self._safe_child(self.output_dir, plan["name"])), "zip", project_dir)
            manifest["artifact"] = archive
            manifest["build_status"] = "success"
        elif plan["type"] == "windows_app":
            self._build_windows_app(project_dir, manifest)
        (project_dir / "vortrex.project.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=True), encoding="utf-8"
        )
        return manifest

    def _build_minecraft_plugin(self, project_dir: Path, manifest: dict[str, Any]) -> None:
        import tool_manager

        maven = tool_manager.get_maven_executable()
        if not maven:
            manifest["build_status"] = "not_available"
            manifest["build_error"] = "Maven wurde nicht gefunden. Installiere Maven und starte Vortrex neu."
            return

        # Resolve a managed JDK via tool_manager (no global PATH/JAVA_HOME changes).
        # Fall back to a system JDK if no internal one is present.
        java_home = None
        java_exe = tool_manager.find_java("21")
        if java_exe:
            java_home = os.path.dirname(os.path.dirname(java_exe))
        else:
            env_home = os.environ.get("JAVA_HOME")
            if env_home and os.path.isfile(os.path.join(env_home, "bin", "java.exe" if os.name == "nt" else "java")):
                java_home = env_home

        env = os.environ.copy()
        if java_home:
            env["JAVA_HOME"] = java_home
            env["PATH"] = os.path.join(java_home, "bin") + os.pathsep + env.get("PATH", "")

        try:
            result = subprocess.run(
                [maven, "-q", "clean", "package", "-DskipTests"],
                cwd=project_dir,
                env=env,
                capture_output=True,
                text=True,
                timeout=180,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            manifest["build_status"] = "failed"
            manifest["build_error"] = f"Maven-Build konnte nicht beendet werden: {exc}"
            return

        if result.returncode != 0:
            manifest["build_status"] = "failed"
            manifest["build_error"] = (result.stderr or result.stdout)[-4000:]
            return

        artifacts = sorted((project_dir / "target").glob("*.jar"))
        if not artifacts:
            manifest["build_status"] = "failed"
            manifest["build_error"] = "Maven war erfolgreich, aber es wurde keine JAR gefunden."
            return

        artifact = artifacts[0]
        output_artifact = self._safe_child(self.output_dir, f"{manifest['name']}.jar")
        shutil.copy2(artifact, output_artifact)
        manifest["status"] = "built"
        manifest["build_status"] = "success"
        manifest["artifact"] = str(output_artifact)
        manifest["files"].append(str(output_artifact.relative_to(self.output_dir)))

    def _build_windows_app(self, project_dir: Path, manifest: dict[str, Any]) -> None:
        """Package only Vortrex's generated desktop template, if PyInstaller is available."""
        pyinstaller = shutil.which("pyinstaller")
        if not pyinstaller:
            manifest["build_status"] = "not_available"
            manifest["build_error"] = "PyInstaller wurde nicht gefunden. Installiere es mit: pip install pyinstaller"
            return
        try:
            result = subprocess.run(
                [pyinstaller, "--noconfirm", "--onefile", "--windowed", "--name", manifest["name"], "main.py"],
                cwd=project_dir, capture_output=True, text=True, timeout=240, check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            manifest["build_status"] = "failed"
            manifest["build_error"] = f"EXE-Build konnte nicht beendet werden: {exc}"
            return
        artifact = project_dir / "dist" / f"{manifest['name']}.exe"
        if result.returncode or not artifact.exists():
            manifest["build_status"] = "failed"
            manifest["build_error"] = (result.stderr or result.stdout)[-4000:]
            return
        output_artifact = self._safe_child(self.output_dir, artifact.name)
        shutil.copy2(artifact, output_artifact)
        manifest["status"] = "built"
        manifest["build_status"] = "success"
        manifest["artifact"] = str(output_artifact)

    def plan(self, prompt: str) -> dict[str, Any]:
        prompt_low = prompt.lower()
        version_match = re.search(r"(?:minecraft|mc)?\s*(1\.\d+(?:\.\d+)?)", prompt_low)
        version = version_match.group(1) if version_match else None

        if any(word in prompt_low for word in ("purpur", "paper", "spigot", "bukkit", "plugin")):
            project_type = "minecraft_plugin"
            platform = self._minecraft_platform(prompt_low)
            name = self._project_name(prompt, "MinecraftPlugin")
            features = self._minecraft_features(prompt_low)
            build_system = "maven"
        elif any(word in prompt_low for word in ("fabric mod", "forge mod", "neoforge mod", "minecraft mod")):
            project_type = "minecraft_mod"
            platform = self._mod_platform(prompt_low)
            name = self._project_name(prompt, "MinecraftMod")
            features = []
            build_system = "gradle"
        elif any(word in prompt_low for word in ("resource pack", "ressourcenpaket", "texture pack", "texturpack")):
            project_type = "minecraft_resource_pack"
            platform = "minecraft-java"
            name = self._project_name(prompt, "ResourcePack")
            features = []
            build_system = "zip"
        elif any(word in prompt_low for word in ("shader", "shaderpack", "shader pack")):
            project_type = "minecraft_shader_pack"
            platform = "iris-optifine"
            name = self._project_name(prompt, "ShaderPack")
            features = []
            build_system = "zip"
        elif any(word in prompt_low for word in (".exe", "exe datei", "desktop app", "windows app", "windows programm")):
            project_type = "windows_app"
            platform = "windows"
            name = self._project_name(prompt, "WindowsApp")
            features = []
            build_system = "pyinstaller"
        elif any(word in prompt_low for word in ("website", "webseite", "web app", "website")):
            project_type = "web_app"
            platform = "web"
            name = self._project_name(prompt, "WebApp")
            features = []
            build_system = "none"
        elif "python" in prompt_low:
            project_type = "python_app"
            platform = "python"
            name = self._project_name(prompt, "PythonApp")
            features = []
            build_system = "pip"
        else:
            project_type = "generic_project"
            platform = "generic"
            name = self._project_name(prompt, "VortrexProject")
            features = []
            build_system = "none"

        return {
            "name": name,
            "type": project_type,
            "platform": platform,
            "version": version,
            "language": "java" if project_type in ("minecraft_plugin", "minecraft_mod") else "python" if project_type == "windows_app" else platform,
            "build_system": build_system,
            "features": features,
            "request": prompt,
        }

    def _files_for_plan(self, plan: dict[str, Any]) -> dict[str, str]:
        if plan["type"] == "minecraft_plugin":
            return self._minecraft_plugin_files(plan)
        if plan["type"] == "minecraft_mod":
            return self._minecraft_mod_files(plan)
        if plan["type"] == "minecraft_resource_pack":
            return self._resource_pack_files(plan)
        if plan["type"] == "minecraft_shader_pack":
            return self._shader_pack_files(plan)
        if plan["type"] == "windows_app":
            return self._windows_app_files(plan)
        if plan["type"] == "python_app":
            return {
                "README.md": self._readme(plan),
                "main.py": "def main():\n    print(\"Vortrex project scaffold\")\n\n\nif __name__ == \"__main__\":\n    main()\n",
                "requirements.txt": "",
            }
        if plan["type"] == "web_app":
            return {
                "README.md": self._readme(plan),
                "index.html": "<!doctype html>\n<html lang=\"de\">\n<head><meta charset=\"utf-8\"><title>Vortrex Project</title></head>\n<body><main><h1>Vortrex Project</h1></main></body>\n</html>\n",
                "styles.css": "body { font-family: sans-serif; margin: 2rem; }\n",
            }
        return {"README.md": self._readme(plan)}

    def _minecraft_plugin_files(self, plan: dict[str, Any]) -> dict[str, str]:
        version = plan["version"] or "1.21.11"
        artifact = plan["name"].lower()
        features = ", ".join(plan["features"]) or "custom feature"
        return {
            "README.md": self._readme(plan),
            "pom.xml": f"""<project xmlns=\"http://maven.apache.org/POM/4.0.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">
  <modelVersion>4.0.0</modelVersion>
  <groupId>de.vortrex</groupId>
  <artifactId>{artifact}</artifactId>
  <version>0.1.0</version>
  <properties><maven.compiler.release>21</maven.compiler.release><project.build.sourceEncoding>UTF-8</project.build.sourceEncoding></properties>
  <repositories><repository><id>papermc</id><url>https://repo.papermc.io/repository/maven-public/</url></repository></repositories>
  <dependencies><dependency><groupId>io.papermc.paper</groupId><artifactId>paper-api</artifactId><version>{version}-R0.1-SNAPSHOT</version><scope>provided</scope></dependency></dependencies>
  <build><plugins><plugin><groupId>org.apache.maven.plugins</groupId><artifactId>maven-compiler-plugin</artifactId><version>3.13.0</version></plugin></plugins></build>
</project>
""",
            "src/main/resources/plugin.yml": f"name: {plan['name']}\nversion: 0.1.0\nmain: de.vortrex.generated.GeneratedPlugin\napi-version: '{version}'\nauthor: Vortrex\ndescription: Generated scaffold for {features}\n",
            "src/main/resources/config.yml": "# Generated configuration. Add validated settings here.\n",
            "src/main/java/de/vortrex/generated/GeneratedPlugin.java": "package de.vortrex.generated;\n\nimport org.bukkit.plugin.java.JavaPlugin;\n\npublic final class GeneratedPlugin extends JavaPlugin {\n    @Override\n    public void onEnable() {\n        getLogger().info(\"Vortrex plugin scaffold enabled\");\n    }\n}\n",
        }

    def _minecraft_mod_files(self, plan: dict[str, Any]) -> dict[str, str]:
        version = plan["version"] or "1.21.1"
        mod_id = re.sub(r"[^a-z0-9_]", "", plan["name"].lower()) or "vortrexmod"
        return {
            "README.md": self._readme(plan),
            "settings.gradle": f"rootProject.name = '{plan['name']}'\n",
            "build.gradle": "plugins {\n    id 'fabric-loom' version '1.9-SNAPSHOT'\n    id 'maven-publish'\n}\n\nversion = '0.1.0'\ngroup = 'de.vortrex'\n\nrepositories { mavenCentral(); maven { url = 'https://maven.fabricmc.net/' } }\n\ndependencies { minecraft 'com.mojang:minecraft:1.21.1'; mappings 'net.fabricmc:yarn:1.21.1+build.3:v2'; modImplementation 'net.fabricmc:fabric-loader:0.16.9'; modImplementation 'net.fabricmc.fabric-api:fabric-api:0.110.0+1.21.1' }\n",
            "src/main/resources/fabric.mod.json": f'{{\n  "schemaVersion": 1,\n  "id": "{mod_id}",\n  "version": "${{version}}",\n  "name": "{plan["name"]}",\n  "environment": "*",\n  "entrypoints": {{ "main": ["de.vortrex.generated.GeneratedMod"] }}\n}}\n',
            "src/main/java/de/vortrex/generated/GeneratedMod.java": "package de.vortrex.generated;\n\nimport net.fabricmc.api.ModInitializer;\n\npublic class GeneratedMod implements ModInitializer {\n    @Override public void onInitialize() { System.out.println(\"Vortrex mod loaded.\"); }\n}\n",
        }

    def _resource_pack_files(self, plan: dict[str, Any]) -> dict[str, str]:
        return {
            "README.md": self._readme(plan) + "\nLege eigene PNG-Texturen in `assets/minecraft/textures/` ab und packe den Ordner danach als ZIP (ohne äußeren Projektordner).\n",
            "pack.mcmeta": '{\n  "pack": {\n    "pack_format": 34,\n    "description": "Vortrex Resource Pack"\n  }\n}\n',
            "assets/minecraft/textures/README.txt": "Lege hier Texturen mit dem korrekten Minecraft-Pfad ab, z. B. block/stone.png.\n",
        }

    def _shader_pack_files(self, plan: dict[str, Any]) -> dict[str, str]:
        return {
            "README.md": self._readme(plan) + "\nDies ist eine kleine Shader-Pack-Vorlage für Iris/OptiFine. Ergänze und teste Shader immer in einer eigenen Welt.\n",
            "shaders/shaders.properties": "screen=Vortrex Shader Pack\n",
            "shaders/gbuffers_basic.vsh": "#version 120\nvoid main() { gl_Position = ftransform(); gl_FrontColor = gl_Color; }\n",
            "shaders/gbuffers_basic.fsh": "#version 120\nvoid main() { gl_FragColor = gl_Color; }\n",
        }

    def _windows_app_files(self, plan: dict[str, Any]) -> dict[str, str]:
        return {
            "README.md": self._readme(plan) + "\nFür eine EXE: `pip install pyinstaller` und danach `build_exe.bat` ausführen.\n",
            "main.py": f"import tkinter as tk\n\nroot = tk.Tk()\nroot.title('{plan['name']}')\nroot.geometry('560x360')\ntk.Label(root, text='{plan['name']}', font=('Segoe UI', 22, 'bold')).pack(pady=(60, 12))\ntk.Label(root, text='Erstellt mit Vortrex AI').pack()\ntk.Button(root, text='Schließen', command=root.destroy).pack(pady=28)\nroot.mainloop()\n",
            "requirements.txt": "pyinstaller>=6.0\n",
            "build_exe.bat": "@echo off\npython -m PyInstaller --noconfirm --onefile --windowed --name VortrexApp main.py\necho Fertig: dist\\VortrexApp.exe\npause\n",
        }

    def _readme(self, plan: dict[str, Any]) -> str:
        return (
            f"# {plan['name']}\n\n"
            "Dieses Projekt wurde von Vortrex als sicherer Scaffold erstellt.\n\n"
            f"- Typ: {plan['type']}\n"
            f"- Plattform: {plan['platform']}\n"
            f"- Version: {plan['version'] or 'nicht angegeben'}\n"
            f"- Build: {plan['build_system']}\n\n"
            "Bei Minecraft-Plugins versucht Vortrex nach der Erstellung automatisch einen Maven-Build.\n"
        )

    def _minecraft_features(self, prompt_low: str) -> list[str]:
        known = {
            "grappling hook": "grappling_hook",
            "grapplinghaken": "grappling_hook",
            "stein": "stone",
            "kupfer": "copper",
            "eisen": "iron",
            "diamant": "diamond",
            "netherite": "netherite",
        }
        return sorted({value for key, value in known.items() if key in prompt_low})

    def _minecraft_platform(self, prompt_low: str) -> str:
        for platform in ("purpur", "paper", "spigot", "bukkit"):
            if platform in prompt_low:
                return platform
        return "paper"

    def _mod_platform(self, prompt_low: str) -> str:
        for platform in ("neoforge", "forge", "fabric"):
            if platform in prompt_low:
                return platform
        return "fabric"

    def _project_name(self, prompt: str, fallback: str) -> str:
        if "grappling" in prompt.lower() or "grapplinghaken" in prompt.lower():
            return "GrapplingHook"
        words = re.findall(r"[A-Za-z0-9]+", prompt)
        candidate = "".join(word.capitalize() for word in words[:3])
        return candidate[:48] or fallback

    def _project_path(self, name: str) -> Path:
        safe_name = re.sub(r"[^A-Za-z0-9_-]", "_", name).strip("._") or "VortrexProject"
        return self._safe_child(self.output_dir, safe_name)

    @staticmethod
    def _safe_child(parent: Path, relative_path: str | Path) -> Path:
        child = (parent / relative_path).resolve()
        if child != parent.resolve() and parent.resolve() not in child.parents:
            raise CreationError("Ungesicherter Dateipfad erkannt.")
        return child
