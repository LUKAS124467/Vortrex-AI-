from flask import Flask, request, jsonify
import requests
import os
import zipfile
import threading
import re
import json
from typing import Any
from creation_engine import CreationEngine, CreationError
import config

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HISTORY_DIR = os.path.join(BASE_DIR, "logs")
HISTORY_FILE = os.path.join(HISTORY_DIR, "history.json")
OUTPUT_DIR = config.OUTPUT_DIR

os.makedirs(HISTORY_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
creation_engine = CreationEngine(OUTPUT_DIR)


@app.route("/health", methods=["GET"])
def health_endpoint():
    return jsonify({"status": "ok", "service": "vortrex-ai-server"})

def load_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    for tab in ("chat", "cowork", "code", "jarvis", "assets", "creator"):
                        if not isinstance(data.get(tab), list):
                            data[tab] = []
                    return data
        except Exception as e:
            print(f"Fehler beim Laden der History: {e}")

    return {
        "chat": [],
        "cowork": [],
        "code": [],
        "jarvis": [],
        "assets": [],
        "creator": []
    }


def save_history():
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history_store, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"Fehler beim Speichern der History: {e}")


history_store = load_history()

def is_minecraft_prompt(user_prompt):
    prompt_low = (user_prompt or "").lower()
    if not prompt_low:
        return False
    if "minecraft" in prompt_low or "minecrft" in prompt_low:
        return True

    patterns = [
        r"\bmods?\b",
        r"\bplugin(s)?\b",
        r"\bpaper\b",
        r"\bpurpur\b",
        r"\bspigot\b",
        r"\bbukkit\b",
        r"\bfabric\b",
        r"\bforge\b",
        r"\bneoforge\b",
        r"\bresource pack\b",
        r"\bressourcenpaket\b",
        r"\btexture pack\b",
        r"\btexturpack\b",
        r"\bshader(s|pack)?\b",
        r"\biris\b",
        r"\boptifine\b",
        r"\bdatapack\b"
    ]
    return any(re.search(pattern, prompt_low) for pattern in patterns)


def finde_version_und_format(user_prompt):
    prompt_low = user_prompt.lower()
    # Standardwerte, falls nichts gefunden wird
    version = "1.21"
    pack_format = 34
    
    # Suche nach Mustern wie 1.21.11, 1.20.2 etc.
    match = re.search(r"1\.\d+(?:\.\d+)?", prompt_low)
    if match:
        version = match.group(0)
        
    # Setze das korrekte pack_format basierend auf der Version
    if "1.21" in version:
        pack_format = 34
    elif "1.20.5" in version or "1.20.6" in version:
        pack_format = 32
    elif "1.20" in version:
        pack_format = 15
    elif "1.19" in version:
        pack_format = 9
        
    return version, pack_format

def generiere_transparente_png_bytes():
    return b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x10\x08\x06\x00\x00\x00\x1f\xf3\xffa\x00\x00\x00\x0bIDATx\x9cc`\x00\x00\x00\x00\x00\x01\x00\x18\xdd\x8d\xb0\x00\x00\x00\x00IEND\xaeB`\x82'

def zip_hintergrund_task(user_prompt):
    try:
        output_basis = OUTPUT_DIR
        os.makedirs(output_basis, exist_ok=True)
        
        prompt_low = user_prompt.lower()
        version, pack_format = finde_version_und_format(user_prompt)
        
        if any(w in prompt_low for w in ["resource", "fire", "texture", "pack", "shield"]):
            name = "LowShieldPack" if "shield" in prompt_low else "LowFirePack"
            zip_dateiname = f"{name}_{version}.zip"
            zip_pfad = os.path.join(output_basis, zip_dateiname)
            
            mcmeta_inhalt = (
                "{\n"
                "  \"pack\": {\n"
                f"    \"pack_format\": {pack_format},\n"
                f"    \"description\": \"§eVortrex Custom Pack v{version} - Erstellt für Sir!\"\n"
                "  }\n"
                "}"
            )
            
            with zipfile.ZipFile(zip_pfad, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.writestr("pack.mcmeta", mcmeta_inhalt)
                png_daten = generiere_transparente_png_bytes()
                
                if "shield" in prompt_low:
                    zipf.writestr("assets/minecraft/textures/entity/shield_base.png", png_daten)
                else:
                    zipf.writestr("assets/minecraft/textures/block/fire_0.png", png_daten)
                    zipf.writestr("assets/minecraft/textures/block/fire_1.png", png_daten)
    except Exception as e:
        print(f"[Fehler] Lokale Pack-Generierung fehlgeschlagen: {e}")

def compact_answer(text):
    value = (text or "").strip()
    if not value:
        return "Antwort leer"
    value = re.sub(r"\s+", " ", value)
    value = value.replace('"', '')
    value = value.replace("Sir, ", "")
    value = value.replace("Ich habe deine Anfrage verstanden: ", "")
    value = value.replace("ich habe deine Anfrage verstanden: ", "")
    value = value.replace("ich habe deine Anfrage verstanden:", "")
    value = value.replace("Ich habe dein Minecraft-Projekt erkannt: ", "Minecraft: ")
    value = value.replace("Wenn du willst, kann ich daraus sofort ein passendes Projekt-Layout erzeugen.", "")
    value = value.replace("Dein Auftrag: ", "Auftrag: ")
    value = value.strip()
    if len(value) <= 240:
        return value

    sentence_matches = list(re.finditer(r"[.!?](?:\s|$)", value[:240]))
    if sentence_matches:
        return value[: sentence_matches[-1].start() + 1].strip()
    return value


def generate_local_response(user_prompt, system_prompt=""):
    prompt = (user_prompt or "").strip()
    if not prompt:
        return "Keine Eingabe"

    prompt_low = prompt.lower()
    if is_minecraft_prompt(prompt):
        return compact_answer(f"Minecraft: {prompt} | Mod/Plugin/Pack/Shader")

    if any(word in prompt_low for word in ["app", "programm", "software", "website", "tool", "gui", "interface"]):
        return compact_answer(f"Lösung: {prompt} | Struktur + Dateien")

    if any(word in prompt_low for word in ["minecraft", "mod", "plugin", "resource pack", "shader", "paper", "purpur", "spigot"]):
        return compact_answer(f"Minecraft: {prompt} | Mod/Plugin/Pack/Shader")

    return compact_answer(f"Lösung: {prompt} | Plan + Dateien")


def has_stale_action_response(text):
    value = (text or "").strip().lower()
    if not value:
        return False
    stale_markers = [
        "aktion erfolgreich ausgeführt",
        "aktion wurde erfolgreich",
        "die aktion wurde erfolgreich",
        "erfolgreich ausgeführt",
        "✅ aktion",
    ]
    return any(marker in value for marker in stale_markers)


def frage_alternative_ki(system_prompt, user_prompt):
    gemini_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if gemini_key:
        gemini_url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            "gemini-2.0-flash:generateContent"
        )
        gemini_payload = {
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
            "generationConfig": {
                "temperature": 0.4,
                "maxOutputTokens": 300,
            },
        }
        try:
            gemini_response = requests.post(
                gemini_url,
                params={"key": gemini_key},
                json=gemini_payload,
                timeout=30,
            )
            if gemini_response.ok:
                gemini_data = gemini_response.json()
                candidates = gemini_data.get("candidates") or []
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts") or []
                    answer = "".join(
                        part.get("text", "")
                        for part in parts
                        if isinstance(part, dict)
                    ).strip()
                    if answer and not has_stale_action_response(answer):
                        return compact_answer(answer)
            else:
                print(
                    f"[Gemini] HTTP {gemini_response.status_code}: "
                    f"{gemini_response.text[:500]}"
                )
        except requests.RequestException as exc:
            print(f"[Gemini] Verbindung fehlgeschlagen: {exc}")

    if gemini_key:
        return "Gemini konnte keine Antwort liefern. API-Key und Modellzugriff prüfen."

    url = "https://text.pollinations.ai/"
    payload = {
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "private": True
    }
    t = threading.Thread(target=zip_hintergrund_task, args=(user_prompt,))
    t.daemon = True
    t.start()
    
    try:
        response = requests.post(url, json=payload, timeout=15)
        if response.status_code == 200 and response.text.strip():
            text = response.text.strip()
            if (
                not has_stale_action_response(text)
                and "ich habe deine anfrage verstanden" not in text.lower()
            ):
                return text
        if response.status_code == 402:
            return "KI-Dienst nicht verfügbar: API-Schlüssel oder Bezahlzugang erforderlich."
    except requests.RequestException as exc:
        return f"KI-Dienst nicht erreichbar: {exc}"
    return "Kein KI-Dienst konfiguriert. GEMINI_API_KEY setzen."

@app.route("/api/history", methods=["GET"])
def get_history(): return jsonify(history_store)

@app.route("/api/clear", methods=["POST"])
def clear_chat():
    data = request.json or {}
    tab = data.get("tab", "all")
    if tab in history_store:
        history_store[tab].clear()
    else:
        for k in history_store.keys():
            history_store[k].clear()
    save_history()
    return jsonify({"status": "success"})

@app.route("/api/chat", methods=["POST"])
def chat_endpoint():
    data = request.json or {}
    msg = data.get("message", "").strip()
    if not msg: return jsonify({"answer": "Kein Text empfangen, Sir."})
    history_store["chat"].append({"sender": "user", "text": msg})
    save_history()
    ki_res = frage_alternative_ki("Du bist Vortrex AI. Antworte auf Deutsch und sprich den Nutzer mit Sir an.", msg)
    if has_stale_action_response(ki_res):
        ki_res = generate_local_response(msg)
    history_store["chat"].append({"sender": "jarvis", "text": ki_res})
    save_history()
    return jsonify({"answer": ki_res})

@app.route("/api/cowork", methods=["POST"])
def cowork_endpoint():
    data = request.json or {}
    msg = data.get("message", "").strip()
    if not msg: return jsonify({"answer": "Leerer Input."})
    history_store["cowork"].append({"sender": "user", "text": msg})
    save_history()
    ki_res = frage_alternative_ki("Du bist der Vortrex CoWork-Assistent. Unterstütze bei Aufgaben.", msg)
    if has_stale_action_response(ki_res):
        ki_res = generate_local_response(msg)
    history_store["cowork"].append({"sender": "vortrex", "text": ki_res})
    save_history()
    return jsonify({"answer": ki_res})

@app.route("/api/smart_code", methods=["POST"])
def code_endpoint():
    data = request.json or {}
    prompt = data.get("prompt", "").strip()
    if not prompt: return jsonify({"result": "Kein Code-Prompt vorhanden."})
    history_store["code"].append({"sender": "user", "text": prompt})
    version, _ = finde_version_und_format(prompt)
    ki_res = f"Ich erstelle ein Resource Pack direkt für Version {version} im Ausgabe-Verzeichnis, Sir!"
    history_store["code"].append({"sender": "vortrex", "text": ki_res})
    save_history()
    return jsonify({"result": ki_res})

@app.route("/api/create", methods=["POST"])
def create_endpoint():
    data = request.json or {}
    prompt = str(data.get("prompt", "")).strip()
    if not prompt:
        return jsonify({"error": "Kein Erstellungsauftrag vorhanden."}), 400

    try:
        manifest = creation_engine.create(prompt)
    except CreationError as exc:
        return jsonify({"error": str(exc)}), 400
    except OSError as exc:
        return jsonify({"error": f"Projekt konnte nicht geschrieben werden: {exc}"}), 500

    history_store["creator"].append({
        "sender": "user",
        "text": prompt,
    })
    history_store["creator"].append({
        "sender": "vortrex",
        "text": f"Projekt {manifest['name']} wurde als Scaffold erstellt.",
        "manifest": manifest,
    })
    save_history()
    return jsonify({"status": "created", "project": manifest}), 201


@app.route("/api/build", methods=["POST"])
def build_endpoint():
    data = request.json or {}
    project_dir = data.get('project_dir')
    if not project_dir:
        return jsonify({'error': 'project_dir required'}), 400

    # Ensure project_dir is under OUTPUT_DIR for safety
    abs_project = os.path.abspath(project_dir)
    if not abs_project.startswith(os.path.abspath(OUTPUT_DIR)):
        return jsonify({'error': 'project_dir must be under OUTPUT_DIR'}), 400

    from build.build_manager import run_build
    res = run_build(abs_project)
    return jsonify(res)

@app.route("/api/jarvis", methods=["POST"])
def jarvis_endpoint():
    data = request.json or {}
    msg = data.get("message", "").strip()
    access_level = str(data.get("access_level", "none")).strip().lower()
    if not msg: return jsonify({"answer": "System-Kern wartet auf Eingabe."})
    history_store["jarvis"].append({"sender": "user", "text": msg})
    access_policy = {
        "none": {
            "label": "Kein PC-Zugriff",
            "actions": [],
            "prompt": "Du darfst keine PC-Aktionen vorschlagen oder ausführen. Antworte nur als Gesprächspartner.",
        },
        "basic": {
            "label": "Basiszugriff",
            "actions": ["open_url", "open_folder", "launch_app"],
            "prompt": "Du darfst nur Webseiten, Ordner und freigegebene Apps öffnen.",
        },
        "extended": {
            "label": "Erweiterter Zugriff",
            "actions": ["open_url", "open_folder", "launch_app", "edit_file", "manage_project"],
            "prompt": "Du darfst zusätzlich Dateien und Projekte verwalten, aber keine riskanten Systemänderungen durchführen.",
        },
        "confirm": {
            "label": "Bestätigung erforderlich",
            "actions": ["open_url", "open_folder", "launch_app", "edit_file", "manage_project", "needs_confirmation"],
            "prompt": "Vor jeder wichtigen oder potenziell folgenreichen Aktion musst du deutlich um Bestätigung bitten.",
        },
        "full": {
            "label": "Ganzer PC-Zugriff",
            "actions": ["open_url", "open_folder", "launch_app", "edit_file", "manage_project", "run_command", "click", "type"],
            "prompt": "Du darfst alle vorgesehenen PC-Funktionen nutzen, solltest aber kritische Aktionen klar benennen.",
        },
    }
    policy = access_policy.get(access_level, access_policy["none"])
    allowed_actions = set(policy["actions"])
    system_prompt = (
        "Du bist Vortrex AI (PC-Assistent). Antworte IMMER in JSON (keine Markdown-Backticks, kein Fließtext). "
        "JSON-Schema: {\"answer\": string, \"actions\": [action, ...]}.\n"
        "action-Schema: {\"type\": string, ...}.\n"
        "Erlaubte action-Typen: "
        "open_url (Felder: url), open_folder (Felder: path), launch_app (Felder: app), edit_file, manage_project, run_command, click, type.\n"
        "launch_app-app darf nur: discord, browser.\n"
        "actions dürfen leer sein, falls keine PC-Aktion nötig oder sinnvoll ist.\n"
        f"Zugriffsmodus: {policy['label']}. {policy['prompt']} "
        "Antworte in Deutsch und sprich den Nutzer als \"Sir\" an."
    )

    ki_res_text = frage_alternative_ki(system_prompt, msg)

    def extract_json_obj(text: str) -> Any:
        if not isinstance(text, str):
            return None
        stripped = text.strip()
        if stripped.startswith("{") and stripped.endswith("}"):
            try:
                return json.loads(stripped)
            except Exception:
                pass
        try:
            start = stripped.find("{")
            end = stripped.rfind("}")
            if start >= 0 and end > start:
                return json.loads(stripped[start : end + 1])
        except Exception:
            pass
        return None

    parsed = extract_json_obj(ki_res_text) or {}
    answer = parsed.get("answer") if isinstance(parsed, dict) else None
    actions = parsed.get("actions") if isinstance(parsed, dict) else None
    if not isinstance(answer, str) or not answer.strip():
        answer = ki_res_text
    if not isinstance(actions, list):
        actions = []
    filtered_actions = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        action_type = str(action.get("type", "")).strip()
        if action_type and action_type in allowed_actions:
            filtered_actions.append(action)

    history_store["jarvis"].append({"sender": "jarvis", "text": answer})
    save_history()
    return jsonify({"answer": answer, "actions": filtered_actions, "access_level": access_level})

@app.route("/api/assets", methods=["POST"])
def assets_endpoint():
    data = request.json or {}
    msg = data.get("message", "").strip()
    file_path = data.get("file_path", "").strip()
    
    text_fuer_historie = msg
    if file_path: text_fuer_historie = f"[Datei: {os.path.basename(file_path)}] {msg}"
    history_store["assets"].append({"sender": "user", "text": text_fuer_historie})
    
    if not is_minecraft_prompt(msg):
        ki_res = "⚠️ Minecraft Things akzeptiert nur Minecraft-Projekte: Mods, Plugins, Paper/Purpur/Spigot, Resource Packs und Shader."
    elif file_path:
        dateiname = os.path.basename(file_path).lower()
        if dateiname.endswith(".zip"):
            ki_res = f"📦 [Asset Core]: Resource Pack '{os.path.basename(file_path)}' verarbeitet."
        else:
            ki_res = "❓ Unbekanntes Format."
    else:
        ki_res = frage_alternative_ki("Du bist das Vortrex Asset Studio für Minecraft-Mods, Plugins, Resource Packs und Shader.", msg)
        
    history_store["assets"].append({"sender": "vortrex", "text": ki_res})
    save_history()
    return jsonify({"answer": ki_res})

@app.route("/api/action", methods=["POST"])
def action_endpoint():
    data = request.json or {}
    msg = str(data.get("message") or data.get("prompt") or "").strip()
    if msg:
        answer = generate_local_response(msg)
        return jsonify({"status": "success", "result": answer, "answer": answer})
    return jsonify({"status": "success", "result": "Die Anfrage wurde verarbeitet, Sir. Bitte formuliere sie genauer, damit ich sie sauber umsetzen kann.", "answer": "Die Anfrage wurde verarbeitet, Sir. Bitte formuliere sie genauer, damit ich sie sauber umsetzen kann."})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5050))
    app.run(host="0.0.0.0", port=port)
