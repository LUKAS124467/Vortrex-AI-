# Vortrex AI Cloud Deployment

## 1. Upload to GitHub

Create a private repository and upload the source files. Do not upload API keys,
`.env` files, `logs`, `.venv`, `dist`, or `build` folders.

## 2. Deploy on Render

Create a Web Service from the repository. Render detects `render.yaml`.
Set the secret environment variable:

```text
GEMINI_API_KEY=your-key
```

The service starts with Gunicorn and listens on Render's `PORT`.

## 3. Connect the desktop app

After deployment, set `VORTREX_SERVER_URL` to the Render URL while building
the EXE, for example:

```powershell
$env:VORTREX_SERVER_URL = "https://vortrex-ai-server.onrender.com"
.\build_vortrex_onefile.bat
```

If the variable is not set, the app uses the local server
`http://127.0.0.1:5050`.
