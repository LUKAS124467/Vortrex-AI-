@echo off
setlocal

set "ROOT=%~dp0"
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if not exist "%ISCC%" (
  echo Fehler: Inno Setup 6 wurde nicht gefunden.
  exit /b 1
)

"%ISCC%" "%ROOT%installer\Vortrex AI.iss"
if errorlevel 1 (
  echo Installer-Build fehlgeschlagen.
  exit /b 1
)

echo Fertig: %ROOT%installer\Output\Vortrex AI Setup.exe
endlocal

