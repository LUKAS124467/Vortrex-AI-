$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Stop-TrackedProcesses {
    $candidatePids = @()
    $processes = Get-CimInstance Win32_Process | Where-Object {
        $_.Name -eq 'Vortrex AI.exe' -or
        ($_.Name -eq 'python.exe' -and $_.CommandLine -match 'vortrex_app.py') -or
        ($_.Name -eq 'python.exe' -and $_.CommandLine -match 'vortrex_server.py')
    }

    foreach ($p in $processes) {
        $candidatePids += [int]$p.ProcessId
    }

    $candidatePids = $candidatePids | Sort-Object -Unique
    foreach ($procId in $candidatePids) {
        try {
            if ($procId -ne $PID) {
                Stop-Process -Id $procId -Force -ErrorAction Stop
            }
        } catch {
            Write-Host "Warnung: Prozess $procId konnte nicht beendet werden."
        }
    }
}

Stop-TrackedProcesses

$pythonExe = Join-Path $root '.venv\Scripts\python.exe'
$pythonwExe = Join-Path $root '.venv\Scripts\pythonw.exe'
if (-not (Test-Path $pythonExe)) {
    $pythonExe = 'py'
    $pythonwExe = 'py'
}
if (-not (Test-Path $pythonwExe) -and $pythonwExe -ne 'py') {
    $pythonwExe = $pythonExe
}

$lockPath = Join-Path $env:APPDATA 'Vortrex AI\vortrex.lock'
if (Test-Path $lockPath) {
    Remove-Item $lockPath -Force -ErrorAction SilentlyContinue
}

if (Test-Path (Join-Path $root 'vortrex_server.py')) {
    $serverCmd = @('vortrex_server.py')
    if ($pythonwExe -eq 'py') {
        Start-Process -FilePath 'py' -ArgumentList @('-3', 'vortrex_server.py') -WorkingDirectory $root -WindowStyle Hidden
    } else {
        Start-Process -FilePath $pythonwExe -ArgumentList $serverCmd -WorkingDirectory $root -WindowStyle Hidden
    }
    Start-Sleep -Seconds 2
}

if (Test-Path (Join-Path $root 'vortrex_app.py')) {
    if ($pythonwExe -eq 'py') {
        Start-Process -FilePath 'py' -ArgumentList @('-3', 'vortrex_app.py') -WorkingDirectory $root -WindowStyle Normal
    } else {
        Start-Process -FilePath $pythonwExe -ArgumentList @('vortrex_app.py') -WorkingDirectory $root -WindowStyle Normal
    }
    Write-Host "Gestartet: $root\vortrex_app.py"
    exit 0
}

throw 'Keine Vortrex AI-Startquelle gefunden. Bitte erst bauen oder Source-Dateien prüfen.'
