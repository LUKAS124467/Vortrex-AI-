e@echo off
setlocal
set "ROOT=%~dp0"
wscript.exe "%ROOT%start_vortrex_hidden.vbs"
exit /b 0
