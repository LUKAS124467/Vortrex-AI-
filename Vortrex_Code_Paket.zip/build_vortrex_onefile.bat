@echo off
setlocal

set "ROOT=%~dp0"
set "PYTHON=%ROOT%.venv\Scripts\python.exe"

if not exist "%PYTHON%" (
  echo Fehler: Die lokale .venv wurde nicht gefunden.
  exit /b 1
)

echo Installiere/aktualisiere Build-Abhaengigkeit PyInstaller ...
"%PYTHON%" -m pip install --upgrade PyInstaller >nul
if errorlevel 1 (
  echo PyInstaller konnte nicht installiert werden.
  exit /b 1
)

echo Veraltete Vortrex-Prozesse beenden ...
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ids = Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'Vortrex AI.exe' -or ($_.Name -eq 'python.exe' -and $_.CommandLine -match 'vortrex_app.py') } | Select-Object -ExpandProperty ProcessId; foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }"

echo Alte Build-Kopien bereinigen ...
if exist "%ROOT%dist" rmdir /s /q "%ROOT%dist"
if exist "%ROOT%artifacts\dist" rmdir /s /q "%ROOT%artifacts\dist"

echo Erstelle die einzelne EXE ...
"%PYTHON%" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --name "Vortrex AI" ^
  --icon "%ROOT%assets\icon.ico" ^
  --collect-all customtkinter ^
  --collect-all PIL ^
  --add-data "%ROOT%assets;assets" ^
  --add-data "%ROOT%version.txt;." ^
  "%ROOT%vortrex_app.py"

if errorlevel 1 (
  echo Build fehlgeschlagen.
  exit /b 1
)

echo Fertig: %ROOT%dist\"Vortrex AI.exe"
endlocal
