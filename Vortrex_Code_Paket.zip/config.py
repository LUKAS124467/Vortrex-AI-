import os
import sys

APP_NAME = "Vortrex AI"

APP_VERSION = "0.1.0"

SERVER_URL = os.environ.get(
    "VORTREX_SERVER_URL",
    "http://127.0.0.1:5050",
).rstrip("/")
SERVER_FALLBACK_URLS = [
    SERVER_URL,
]


def _resource_base_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


RESOURCE_BASE_DIR = _resource_base_dir()


def resource_path(*parts):
    return os.path.join(RESOURCE_BASE_DIR, *parts)


ICON_PATH = resource_path("assets", "icon.ico")

LOGO_PATH = resource_path("assets", "logo.png")

SPLASH_PATH = resource_path("assets", "splash.png")

# Application directories
APP_BASE_DIR = os.path.dirname(os.path.abspath(sys.executable)) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
TOOLS_DIR = os.path.join(APP_BASE_DIR, "tools")

APP_DATA_DIR = os.path.join(
    os.environ.get("APPDATA", APP_BASE_DIR),
    "Vortrex AI",
)
SETTINGS_FILE = os.path.join(APP_DATA_DIR, "settings.json")
LOGS_DIR = os.path.join(APP_DATA_DIR, "logs")
CHATS_DIR = os.path.join(LOGS_DIR, "chats")

DEFAULT_OUTPUT_DIR = os.path.join(
    os.path.expanduser("~"),
    "Documents",
    "Vortrex AI Output",
)

# Use a predictable output folder until the first-run wizard overrides it.
OUTPUT_DIR = DEFAULT_OUTPUT_DIR
